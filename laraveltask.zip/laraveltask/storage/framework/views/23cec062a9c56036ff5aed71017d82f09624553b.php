<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="page-header">
                    <h2>Task Detail</h2>
                </div>
                <div class="card">
                    <div class="card-header"><?php echo e($task->title); ?></div>

                    <div class="card-body">
                        <?php echo e($task->description); ?>

                    </div>
                    <div class="card-footer">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $task)): ?>
                        <a href="/tasks/<?php echo e($task->id); ?>/edit" class="btn btn-warning">Edit Task</a>

                        <form style="float:right" method="POST" action="/tasks/<?php echo e($task->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button class="btn btn-danger" type="submit">Delete</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>